import React from 'react';
import { Link } from 'react-router-dom';
import "./error.css";

const NotFoundPage = () => {
    return (
        <div className="not-found-container">
            <h1>404</h1>
            <h2>Page Not Found</h2>
            <p>We're sorry, but the page you were looking for doesn't exist.</p>
            <Link to="/home">Go to Home</Link>
        </div>
    );
};

export default NotFoundPage;
