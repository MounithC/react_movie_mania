
import { useState } from 'react';
import { Link } from "react-router-dom";
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import "./Register.css";
import { MdEmail } from "react-icons/md";
import { FaLock } from "react-icons/fa";

const Login = () => {
    const [email, setEmail] = useState();
    const [password, setPassword] = useState();
    const navigate = useNavigate();

    const handleSubmit = (event) => {
        event.preventDefault();
        
    
    
        
        axios.post( 'http://localhost:3001/login', {email, password})
        .then(result => {
            console.log(result);
            if (result.data.success) {
                console.log("Login Success");
                alert('Login successful!');

                // Store user data in local storage
                localStorage.setItem('name', result.data.user.name);
                localStorage.setItem('email', result.data.user.email);

                navigate('/home');
            }
            else{
                alert('Incorrect password! Please try again.');
            }
        })
        .catch(err => console.log(err));
    }





    return (
        <div className='loginBody'>

        <div className='wrapper'>
        <form onSubmit={handleSubmit}>
        <h2>Login</h2>
        <div className='input-box'>
        <input 
                                type="email" 
                                placeholder="Enter Email"
                                className="form-control" 
                                id="exampleInputEmail1" 
                                onChange={(event) => setEmail(event.target.value)}
                                required
                            /> 
                             <MdEmail style={{ position: 'absolute', left: '15px', top: '50%', transform: 'translateY(-50%)' }}/>
        </div>
        <div className='input-box'>
        <input 
                                type="password" 
                                placeholder="Enter Password"
                                className="form-control" 
                                id="exampleInputPassword1" 
                                onChange={(event) => setPassword(event.target.value)}
                                required
                            />
                             <FaLock style={{ position: 'absolute', left: '15px', top: '50%', transform: 'translateY(-50%)' }} />

        </div>
        <button type="submit" className="btn btn-primary">Login</button>
        </form>
        <div className='register-link'>
        <p >Dont have an account?</p>
                    <Link to='/' className="btn-link"><button className='btn'>Register</button></Link>
    </div>
    </div>
    </div>
       
    )
}

export default Login