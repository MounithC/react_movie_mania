
import { useState } from 'react';
import { Link } from "react-router-dom";
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import "./Register.css";
import { FaUserAlt } from "react-icons/fa";
import { MdEmail } from "react-icons/md";
import { FaLock } from "react-icons/fa";


const Register = () => {
    const [name, setName] = useState();
    const [email, setEmail] = useState();
    const [password, setPassword] = useState();
    const [confirmPassword, setConfirmPassword] = useState();
  
    const navigate = useNavigate();


    const handleSubmit = (event) => {
        event.preventDefault();

        const passwordPattern = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$/;

        if (!passwordPattern.test(password)) {
            alert("Password must contain at least one lowercase letter, one uppercase letter, one digit, and be at least 8 characters long.");
            return;
        }

        localStorage.setItem('name', name);
    localStorage.setItem('email', email);
    localStorage.setItem('password', password);

    
    if (password !== confirmPassword) {
        alert("Passwords do not match. Please try again.");
        return;
    }
        
        axios.post( 'http://localhost:3001', {name, email, password})
        .then(result => {
            console.log(result);
            if(result.data === "Already registered"){
                alert("E-mail already registered!.Please Login to proceed.");
                navigate('/login');
            }
          
            else{
                alert("Registered and login successfully! ")
                navigate('/home');
            }
            
        })
        .catch(err => console.log(err));
    }
   


    return (
        <div className='loginBody'>
        <div className='wrapper'>
        <form onSubmit={handleSubmit}>
            <h2 className='heading'>Register</h2>
            <div className='input-box'>
            
            <input 
                                type="text"
                                placeholder="Enter name"
                                className="form-control" 
                                id="exampleInputname" 
                                onChange={(event) => setName(event.target.value)}
                                required
                                
                            /> 
                             <FaUserAlt style={{ position: 'absolute', left: '15px', top: '50%', transform: 'translateY(-50%)' }} />
                            
            </div>
            <div className='input-box'>
            <input 
                                type="email" 
                                placeholder="Enter Email"
                                className="form-control" 
                                id="exampleInputEmail1" 
                                onChange={(event) => setEmail(event.target.value)}
                                required
                            />
                            <MdEmail style={{ position: 'absolute', left: '15px', top: '50%', transform: 'translateY(-50%)' }}/>


            </div>
            <div className='input-box'>

            <input 
                                type="password" 
                                placeholder="Create Password"
                                className="form-control" 
                                id="exampleInputPassword1" 
                                onChange={(event) => setPassword(event.target.value)
                                    }
                                
                               
                                required
                               
                            />
                            <FaLock  style={{ position: 'absolute', left: '15px', top: '50%', transform: 'translateY(-50%)' }}/>

            </div>
            <div className='input-box'>

            <input 
                                type="password" 
                                placeholder="Confirm Password"
                                className="form-control" 
                                id="exampleInputPassword1" 
                                onChange={(event) => setConfirmPassword(event.target.value)
                                }
                               
                                required
                            />
                            <FaLock  style={{ position: 'absolute', left: '15px', top: '50%', transform: 'translateY(-50%)' }}/>

            </div>
            <button type="submit" className="btn ">Register</button>
        </form>
        <div className='register-link'>
        <p className='container my-2'>Already have an account ?</p>
                    <Link to='/login' className="btn-link"><button className='btn'>Login</button></Link>
                    </div>
     </div>
     </div>
    )
}

export default Register