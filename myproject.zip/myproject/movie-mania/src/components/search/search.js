import { useEffect } from "react";
import { useState } from 'react';
import MovieCard from "./Moviecard.jsx"
import "./search.css"
import { FaSearch } from "react-icons/fa";

const API_URL = "http://www.omdbapi.com?apikey=b6003d8a";
 
const Search = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [movies, setMovies] = useState([]);
 
  useEffect(() => {
    searchMovies("Avengers");
  }, []);
 
  const searchMovies = async (title) => {
    const response = await fetch(`${API_URL}&s=${title}`);
    const data = await response.json();
 
    setMovies(data.Search);
  };
 

  return (
    <>
    <div className="search">
          <input type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            onKeyPress={(e) => {
              if (e.key === 'Enter') {
                searchMovies(searchTerm);
              }
            }}
            placeholder="Search by movie,year"
          />
          <FaSearch className="img" onClick={() => searchMovies(searchTerm)}/>
         
     
          </div>
          <div>
          {movies?.length > 0 ? (
          <div className="container">
            {movies.map((movie) => (
              <MovieCard movie={movie} />
            ))}
          </div>
        ) : (
          <div className="empty">
            <h2>NO MOVIES FOUND</h2>
          </div>
        )}
        </div>
      
    </>
  );
};
export default Search