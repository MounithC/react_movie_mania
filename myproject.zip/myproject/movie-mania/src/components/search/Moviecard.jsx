import React from "react";
import "./Moviecard.css";


const MovieCard = ({ movie: { Year, Poster, Title, Type } }) => {
    return (
      <div className="movie1" key={Year}>
        
   
        <div className="movie1-img">
          <img
            src={Poster !== "N/A" ? Poster : "https://via.placeholder.com/400"}
            alt={Title}
          />
        </div>
   
        <div className="movie1-details">
          <span className="type">{Type}</span>
          <h3 className="title">{Title}</h3>
          <div className="movie1-year">
          <p>{Year}</p>
        </div>
        </div>
      </div>
    );
  };
   
  export default MovieCard;