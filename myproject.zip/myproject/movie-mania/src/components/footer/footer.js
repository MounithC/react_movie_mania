import React from 'react';
import {FaYoutube, FaTwitter, FaReddit, FaInstagram} from 'react-icons/fa';
import './footer.css';


const Footer1 = () => { 
    return ( 
        <div className='footer-text'>
                <h2>Follow us on</h2>
           
        <div className="footer-icons">
            
            <FaYoutube className='icon'/>
            <FaReddit className='icon'/>
            <FaTwitter className='icon' />
            <FaInstagram className='icon'/>

       
        </div>
        <div className="footer-content">
            <h5>© 2024 MovieMania. All rights reserved.
            </h5>
        </div>
        </div>
        
    )
}

export default Footer1
