import React from 'react'
import './f1.css';

const Footer = () => {
    return (
        <>
            <div className="Footer">
                <div className="container">
                    <div className="row">
                        <div className="col-md-6 col-lg-5 col-12 ft-1">
                            <h3><span>Moviemania</span></h3>
                            <p>Movie Mania is designed to enhance your movie-watching experience. So sit back, grab your popcorn, and let Movie Mania guide you through the magic of the movies!.</p>
                            <div className="footer-icons">
    <a href="https://www.facebook.com/" target="_blank" rel="noopener noreferrer">
        <i className="fa-brands fa-facebook"></i>
    </a>
    <a href="https://twitter.com/" target="_blank" rel="noopener noreferrer">
        <i className="fa-brands fa-twitter"></i>
    </a>
    <a href="https://www.instagram.com/" target="_blank" rel="noopener noreferrer">
        <i className="fa-brands fa-instagram"></i>
    </a>
    <a href="https://www.linkedin.com/in" target="_blank" rel="noopener noreferrer">
        <i className="fa-brands fa-linkedin-in"></i>
    </a>
</div>

                        </div>
                        <div className="col-md-6 col-lg-3 col-12 ft-2">
                            <h5>Quick Links</h5>
                            <ul>
                                <li className="nav-item">
                                    <a className="" href="/">Services</a>
                                </li>
                                <li className="nav-item">
                                    <a className="" href="/movies/aboutus">About Us</a>
                                </li>
                                <li className="nav-item">
                                    <a className="" href="/movies/contactus">Contact Us</a>
                                </li>
                                
                               
                            </ul>
                        </div>
                        <div className="col-md-6 col-lg-4 col-12 ft-3">
                            <h5>Contact Info</h5>
                            <p><i class="fa-solid fa-phone-volume"></i> +91 9353699464</p>
                            <p><i class="fa-solid fa-envelope"></i> mounith@gmail.com</p>
                            <p><i class="fa-solid fa-paper-plane"></i> Bengaluru, Karnataka.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div className='Last-footer'>
                <p>© 2024 MovieMania. All rights reserved.</p>
            </div>
        </>
    )
}

export default Footer