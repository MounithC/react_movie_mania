import React from 'react';
import './about.css'; // assuming AboutUs.css is in the same directory
import aboutUsImage from './ab.jpg';

const AboutUs = () => {
    return (
        <div className="about-us">
            <h1>About Us</h1>
            <img src={aboutUsImage} alt="About us" className="about-us-image" />
            <p>
                We are a team of passionate individuals dedicated to creating the best experiences for our users. Our team is diverse, with a wide range of backgrounds and skills, and we are united by our commitment to excellence and our love for what we do.
            </p>
            <h2>MovieMania App</h2>
            <p>
                Our latest project, the MovieMania app, is a testament to our dedication and passion. This app is designed for movie enthusiasts who want to stay updated with the latest movie releases, reviews, and ratings. With MovieMania, you can explore a vast database of movies, create your own watchlist, and share your reviews with a community of movie lovers. We believe in creating a space where everyone can share their love for cinema and discover new films to enjoy.
            </p>
        </div>
    );
}

export default AboutUs;
