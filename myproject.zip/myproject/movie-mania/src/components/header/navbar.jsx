import React, { useState, useEffect } from "react";
import "./navbar.css";
import "./Header.css"
import logo from "./LOGO.png"
import { Link } from "react-router-dom";
import { FaSearch } from "react-icons/fa";

function Navbar() {
  const [active, setActive] = useState("nav__menu");
  const [icon, setIcon] = useState("nav__toggler");
  const [openbtn11,Setopenbtn11]=useState();
  const [modal,Setmodal]=useState();

 
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  

  useEffect(() => {
    setName(localStorage.getItem('name') || '');
    setEmail(localStorage.getItem('email') || '');
   
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('name');
    localStorage.removeItem('email');
   
    setName('');
    setEmail('');
    
  };

  const navToggle = () => {
    if (active === "nav__menu") {
      setActive("nav__menu nav__active");
    } else setActive("nav__menu");

    // Icon Toggler
    if (icon === "nav__toggler") {
      setIcon("nav__toggler toggle");
    } else setIcon("nav__toggler");
  };

 
    const openbtn1=()=>
    {
     Setopenbtn11(true)
    }
    const closebtn1=()=>
    {
    Setopenbtn11(false)
    }
    const openmodal=()=>
    {
    Setmodal(!modal)
    }
     const modalOpenbtn=()=>
    {
    Setmodal(true)
    }
    const modalClosebtn=()=>
    {
     Setmodal(false)
    }
  return (
    
    
    <nav className="nav">
      <Link to="/home"><img className="header__icon" src={logo} alt="logo" /></Link>
      <ul className={active}>
      <li className="nav__item">
          <a href="/movies/search" className="nav__link">
            <FaSearch /> 
          </a>
        </li>
        <li className="nav__item">
          <a href="/movies/popular" className="nav__link">
            POPULAR
          </a>
        </li>
        <li className="nav__item">
          <a href="/movies/top_rated" className="nav__link">
            TOP RATED
          </a>
        </li>
        <li className="nav__item">
          <a href="/movies/upcoming" className="nav__link">
            UPCOMING
          </a>
        </li>
        <li className="nav__item">
          <a href="/movies/aboutus" className="nav__link">
            ABOUT US
          </a>
        </li>
        <li className="nav__item">
          <a href="/movies/contactus" className="nav__link">
            CONTACT US
          </a>
        </li>
        <li className="nav__item" onMouseEnter={modalOpenbtn} onMouseLeave={modalClosebtn}>Hi,{name}</li>
        <div className="modalmenu" style={{display:modal?"flex":"none"}} onMouseEnter={modalOpenbtn} onMouseLeave={modalClosebtn}>
<div className="modalmenuInfo">
<p><span className="high">Name:</span> {name}</p>
<p><span className="high">Mail:</span> {email}</p>
</div>
<div className="modalmenubtn">
{/* <Link to="/Account"><input className='accBtn' type='button' value={"User Page"}/></Link> */}
<Link to="/"><input className='logout1' type='button' value={"Logout"} onClick={handleLogout} /></Link>
</div>
</div>
       
       
      </ul>
      <div onClick={navToggle} className={icon}>
        <div className="line1"></div>
        <div className="line2"></div>
        <div className="line3"></div>
      </div>
    </nav>
    
  );
  
}

export default Navbar;