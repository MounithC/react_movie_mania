import React from "react";
import './App.css';
import { BrowserRouter as Router, Routes, Route,useLocation } from 'react-router-dom';
import Home from './pages/home/home'
import MovieList from './components/movielist/movielist';
import Movie from './pages/movieDetail/movie';
import  Navbar  from './components/header/navbar';
import AboutUs from './components/about/about';
import ContactUs from './components/contact/contact';
import NotFoundPage from './components/error/error';
import Footer from './components/footer/f1';
import Register from './components/login/Register.jsx';
import Login from './components/login/Login.jsx';
import Search from "./components/search/search.js";



function Layout() {
  const location = useLocation();
  return (
    <>
      {location.pathname !== '/login' && location.pathname !== '/' && <Navbar />}
      <Routes>
        <Route path="/" element={<Register />}></Route>
        <Route path="/login" element={<Login />}></Route>
        <Route path="/home" element={<Home />}></Route>
        <Route path="movie/:id" element={<Movie />}></Route>
        <Route path="movies/:type" element={<MovieList />}></Route>
        <Route path="movies/aboutus" element={<AboutUs/>}></Route>
        <Route path="movies/contactus" element={<ContactUs/>}></Route>
        <Route path="movies/search" element={<Search/>}></Route>
         <Route path="/*" element={<NotFoundPage/>}></Route> 
        
      </Routes>
      {location.pathname !== '/login' && location.pathname !== '/' && <Footer />}
    </>
  );
}

function App() {
  return (
    <div className="App">
      <Router>
        <Layout />
      </Router>
    </div>
  );
}

export default App;

